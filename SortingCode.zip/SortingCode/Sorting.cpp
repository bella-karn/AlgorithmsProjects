#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

int partition(vector<int>& pokemon, int p, int r, int& comparisonCounter1)
{
    int x = pokemon[r];
    int i = p - 1;
    int j = p;
    for (j; j <= r - 1; j++)
    {
        comparisonCounter1++;
        if (pokemon[j] <= x)
        {
            i = i+1;
            int temp = pokemon[i];
            pokemon[i] = pokemon[j];
            pokemon[j] = temp;
        }
        
    }
    int temp = pokemon[i+1];
    pokemon[i+1] = pokemon[r];
    pokemon[r] = temp;
    return i + 1;
}
void quickSort(vector<int>& pokemon, int p, int r, int& comparisonCounter1)
{
    if (p < r)
    {
        int q = partition(pokemon, p, r, comparisonCounter1);
        quickSort(pokemon, p, q - 1, comparisonCounter1);
        quickSort(pokemon, q + 1, r, comparisonCounter1);
    }
}


void insertionSort(vector<int>& pokemon, int& comparisonCounter2)
{
    for (int j = 1; j < pokemon.size(); j++)
    {
        int key = pokemon[j];
        int i = j - 1;
        while (i >= 0 && pokemon[i] > key)
        {
            comparisonCounter2++;
            pokemon[i+1] = pokemon[i];
            i = i - 1;
        }
        comparisonCounter2++;
        pokemon[i+1] = key;
    }
}

void merge (vector<int>& pokemon, int p, int q, int r, int& comparisonCounter3)
{
    int n1 = q - p + 1;
    int n2 = r - q; 
    vector<int> L(n1);
    vector<int> R(n2);
    for(int i = 0; i < n1; i++)
    {
        L[i] = pokemon[p + i];
    }
    for(int j = 0; j < n2; j++)
    {
        R[j] = pokemon[q + j + 1];
    }
    int i = 0;
    int j = 0;
    for(int k = p; k <= r; k++)
    {
        if (i < n1 && (j >= n2 || L[i] <= R[j]))
        {
            pokemon[k] = L[i];
            i++;
        }
        else
        {
            pokemon[k] = R[j];
            j++;
        }
        comparisonCounter3++;
    }
}

void mergeSort(vector<int>& pokemon, int p, int r, int& comparisonCounter3)
{
    if (p < r)
    {
        comparisonCounter3++;
        int q = (p+r)/2;
        mergeSort(pokemon, p, q, comparisonCounter3);
        mergeSort(pokemon, q + 1, r, comparisonCounter3);
        merge(pokemon, p, q, r, comparisonCounter3);
    }
}


// Be sure to note that the data read in lines were supplied by ChatGPT.
int main() {
    for (int i = 0; i < 9; i++)
    {
        int comparisonCounter1 = 0;
        int comparisonCounter2 = 0;
        int comparisonCounter3 = 0;
        string fileName;
        switch(i)
        {
            case 0:
                fileName = "pokemonRandomSmall.csv";
                break;
            case 1:
                fileName = "pokemonRandomMedium.csv";
                break;
            case 2:
                fileName = "pokemonRandomLarge.csv";
                break;
            case 3:
                fileName = "pokemonSortedSmall.csv";
                break;
            case 4:
                fileName = "pokemonSortedMedium.csv";
                break;
            case 5:
                fileName = "pokemonSortedLarge.csv";
                break;
            case 6:
                fileName = "pokemonReverseSortedSmall.csv";
                break;
            case 7:
                fileName = "pokemonReverseSortedMedium.csv";
                break;
            case 8:
                fileName = "pokemonReverseSortedLarge.csv";
                break;
        }
            ifstream input(fileName);
            if (!input.is_open()) {
                cerr << "Failed to open file!" << endl;
                return 1;
            }

            string line;
            // Skip the header line
            getline(input, line);

            vector<double> pokemonNumbers;
            vector<int> pokemon;

            while (getline(input, line)) {
                stringstream ss(line);
                string cell;

                // Split the line by comma
                vector<string> row;
                while (getline(ss, cell, ',')) 
                {
                    row.push_back(cell);
                }

                // Check if the row has two elements
                if (row.size() != 2) {
                    cerr << "Invalid data format in line: " << line << endl;
                    continue;
                }

                // Convert Pokemon Number to integer
                int pokemonNumber;
                stringstream pokemonNumberSS(row[0]);
                if (!(pokemonNumberSS >> pokemonNumber)) {
                    cerr << "Invalid Pokemon Number in line: " << line << endl;
                    continue;
                }

                // Convert Total Stats to floating-point number
                int poke;
                stringstream totalStatSS(row[1]);
                if (!(totalStatSS >> poke)) {
                    cerr << "Invalid Total Stats in line: " << line << endl;
                    continue;
                }

                // Store the values in respective vectors
                pokemonNumbers.push_back(pokemonNumber);
                pokemon.push_back(poke);
            }

            // Make a copy of pokemon for each sorting algorithm
            vector<int> pokemon1 = pokemon;
            vector<int> pokemon2 = pokemon;
            vector<int> pokemon3 = pokemon;

            // sort the lists
            quickSort(pokemon1, 0, pokemon1.size() - 1, comparisonCounter1);
            insertionSort(pokemon2, comparisonCounter3);
            mergeSort(pokemon3, 0, pokemon3.size() - 1, comparisonCounter2);

            cout << "File Name: " << fileName << endl;
            // Print the data and their merged versions
            cout << "Initial Order: ";
            for (size_t i = 0; i < pokemonNumbers.size(); ++i) 
            {
                cout << pokemon[i] << ", ";
            }
            cout << endl;

            cout << "Order after Insertion Sort: ";
            for (size_t i = 0; i < pokemonNumbers.size(); ++i)
            {
                cout << pokemon2[i] << ", ";
            }
            cout << endl;
            cout << endl;
            cout << "Number of comparisons: " << comparisonCounter2 << endl;
            cout << endl;

            cout << "Order after Merge Sort: ";
            for (size_t i = 0; i < pokemonNumbers.size(); ++i)
            {
                cout << pokemon3[i] << ", ";
            }
            cout << endl;
            cout << endl;
            cout << "Number of comparisons: " << comparisonCounter3 << endl;
            cout << endl;

            cout << "Order after Quick Sort: ";
            for (size_t i = 0; i < pokemonNumbers.size(); ++i)
            {
                cout << pokemon1[i] << ", ";
            }
            cout << endl;
            cout << endl;
            cout << "Number of comparisons: " << comparisonCounter1 << endl;
            cout << endl;
    }  
    return 0;
}