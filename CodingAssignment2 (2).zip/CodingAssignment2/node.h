#ifndef NODE_H
#define NODE_H

using namespace std;
class node
{
    public:
    int key;
    node* left;
    node* right;
    node* parent;

    // default constructor
    node(int key);

    // not default constructor
    node(int key, node* left, node* right, node* parent);

    // getter functions
    int getKey() const; 
    node* getLeftChild() const; 
    node* getRightChild() const;
    node* getParent() const;
};

#endif