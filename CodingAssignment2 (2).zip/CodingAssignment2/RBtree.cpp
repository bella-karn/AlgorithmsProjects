#include "RBTree.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

//constructors
Tree::Tree() : root(nullptr) {}
Tree::Tree(int myRoot) : root(new node(myRoot)) {}

node* Tree::rootGet()
{
    return this->root;
}

// once I figured out left rotate I asked chatGPT to write right rotate based on that
void Tree::rightRotate(node* y) {
    if (y == nullptr || y->left == nullptr)
        return;

    node* x = y->left;
    y->left = x->right;
    if (x->right != nullptr) 
    {
        x->right->parent = y;
    }
    x->parent = y->parent;
    if (y->parent == nullptr) 
    {
        // If y was the root
        this->root = x;
    }
    else if (y == y->parent->left) 
    {
        // If y was a left child
        y->parent->left = x;
    } 
    else 
    {
        // If y was a right child
        y->parent->right = x;
    }
    x->right = y;
    y->parent = x;
}

// pretty much just the pseudocode
void Tree::leftRotate(node* x) {
    if (x == nullptr || x->right == nullptr)
        return;

    node* y = x->right;
    x->right = y->left;
    if (y->left != nullptr) 
    {
        y->left->parent = x;
    }
    y->parent = x->parent;
    if (x->parent == nullptr) 
    {
        // If x was the root
        this->root = y;
    } 
    else if (x == x->parent->left) 
    {
        // If x was a left child
        x->parent->left = y;
    } 
    else 
    {
        // If x was a right child
        x->parent->right = y;
    }
    y->left = x;
    x->parent = y;
}

// pretty much just the pseudocode
void Tree::transplant(node* u, node* v)
{
    if (u->parent == nullptr)
    {
        this->root = v;
    }
    else if (u == u->parent->left)
    {
        u->parent->left = v;
    }
    else
    {
        u->parent->right = v;
    }
    if (v != nullptr)
    {
        v->parent = u->parent;
    }
}

// again, just the pseudocode
void Tree::insertFixup(node* z) {
    while (z->parent != nullptr && z->parent->color == "red") {
        if (z->parent == z->parent->parent->left) {
            node* y = z->parent->parent->right;
            if (y != nullptr && y->color == "red") {
                z->parent->color = "black";
                y->color = "black";
                z->parent->parent->color = "red";
                z = z->parent->parent;
            } else {
                if (z == z->parent->right) {
                    z = z->parent;
                    leftRotate(z);
                }
                z->parent->color = "black";
                if (z->parent->parent != nullptr) {
                    z->parent->parent->color = "red";
                    rightRotate(z->parent->parent);
                }
            }
        } else {
            node* y = z->parent->parent->left;
            if (y != nullptr && y->color == "red") {
                z->parent->color = "black";
                y->color = "black";
                z->parent->parent->color = "red";
                z = z->parent->parent;
            } else {
                if (z == z->parent->left) {
                    z = z->parent;
                    rightRotate(z);
                }
                z->parent->color = "black";
                if (z->parent->parent != nullptr) {
                    z->parent->parent->color = "red";
                    leftRotate(z->parent->parent);
                }
            }
        }
    }
    this->root->color = "black"; // Ensure the root is always black
}

// pulled from chatGPT
node* Tree::treeMin(node* root) {
    if (root == nullptr)
        return nullptr;

    // Traverse the left subtree until the leftmost leaf is reached
    while (root->getLeftChild() != nullptr) {
        root = root->getLeftChild();
    }
    
    // Return the leftmost leaf node
    return root;
}

int Tree::inOrderTraversal(node* root, std::ostream& out) {
    if (root == nullptr)
        return 0;
    else {
        // Traverse the left subtree
        int leftHeight = inOrderTraversal(root->getLeftChild(), out);

        // Visit the current node
        out << root->getKey() << " ";

        // Traverse the right subtree
        int rightHeight = inOrderTraversal(root->getRightChild(), out);

        // Calculate the height of the current node
        int currentHeight = 1 + std::max(leftHeight, rightHeight);

        return currentHeight;
    }
}

// Pseduocode!
void Tree::insert(int z) {
    node* newNode = new node(z);
    newNode->left = nullptr;
    newNode->right = nullptr;
    newNode->color = "red";

    node* y = nullptr;
    node* x = this->root;

    while (x != nullptr) {
        y = x;
        if (z < x->key)
            x = x->left;
        else
            x = x->right;
    }

    newNode->parent = y;
    if (y == nullptr)
        this->root = newNode;
    else if (z < y->key)
        y->left = newNode;
    else
        y->right = newNode;

    insertFixup(newNode);
}

// again, pseduocode!
void Tree::deleteNode(int z)
{
    node* target = rootGet();
    while (target != nullptr && target->getKey() != z) {
        if (z < target->getKey())
            target = target->getLeftChild();
        else
            target = target->getRightChild();
    }

    if (target == nullptr) {
        std::cout << "Node with key " << z << " not found." << std::endl;
        return;
    }

    if (target->getLeftChild() == nullptr) {
        transplant(target, target->getRightChild());
    } else if (target->getRightChild() == nullptr) {
        transplant(target, target->getLeftChild());
    } else {
        node* successor = treeMin(target->getRightChild());
        if (successor->getParent() != target) {
            transplant(successor, successor->getRightChild());
            successor->right = target->getRightChild();
            successor->right->parent = successor;
        }
        transplant(target, successor);
        successor->left = target->getLeftChild();
        successor->left->parent = successor;
    }
    delete target; // Delete the node
}



int main()
{
    // the following is modified from my previous assignments code and also from chatGPT because that was from chatGPT
    std::vector<int> numbers1;
    std::vector<int> numbers2;
    std::vector<int> numbers3;

    // Open the file
    std::ifstream file1("testrandom.csv");
    if (file1.is_open()) {
        std::string line;
        while (std::getline(file1, line)) {
            std::istringstream iss(line);
            int num;
            if (iss >> num) {
                // Assuming there's only one column
                numbers1.push_back(num);
            }
        }
        file1.close();
    } else {
        std::cerr << "Unable to open the file." << std::endl;
        return 1;
    }

    std::ifstream file2("deleteNodes.csv");
    if (file2.is_open()) {
        std::string line;
        while (std::getline(file2, line)) {
            std::istringstream iss(line);
            int num;
            if (iss >> num) {
                // Assuming there's only one column
                numbers2.push_back(num);
            }
        }
        file2.close();
    } else {
        std::cerr << "Unable to open the file." << std::endl;
        return 1;
    }

    std::ifstream file3("testBad.csv");
    if (file3.is_open()) {
        std::string line;
        while (std::getline(file3, line)) {
            std::istringstream iss(line);
            int num;
            if (iss >> num) {
                // Assuming there's only one column
                numbers3.push_back(num);
            }
        }
        file3.close();
    } else {
        std::cerr << "Unable to open the file." << std::endl;
        return 1;
    }

    Tree tree1;
    for (int i = 0; i < numbers1.size(); i++)
    {
        tree1.insert(numbers1[i]);
    }
    std::cout << "In-order traversal:" << std::endl;
    int height1 = tree1.inOrderTraversal(tree1.rootGet(), std::cout);
    std::cout << "\nHeight of the tree: " << height1 << std::endl;
    std::cout << endl;

    for (int i = 0; i < numbers2.size(); i++)
    {
        tree1.deleteNode(numbers2[i]);
    }
    std::cout << "In-order traversal after deletion:" << std::endl;
    int height2 = tree1.inOrderTraversal(tree1.rootGet(), std::cout);
    std::cout << "\nHeight of the tree: " << height2 << std::endl;
    std::cout << endl;

    Tree tree3;
    for (int i = 0; i < numbers3.size(); i++)
    {
        tree3.insert(numbers3[i]);
    }
    std::cout << "In-order traversal:" << std::endl;
    int height4 = tree3.inOrderTraversal(tree3.rootGet(), std::cout);
    std::cout << "\nHeight of the tree: " << height4 << std::endl;
    std::cout << endl;

    for (int i = 0; i < numbers2.size(); i++)
    {
        tree3.deleteNode(numbers2[i]);
    }
    std::cout << "In-order traversal after deletion:" << std::endl;
    int height3 = tree3.inOrderTraversal(tree3.rootGet(), std::cout);
    std::cout << "\nHeight of the tree: " << height3 << std::endl;
    std::cout << endl;

    return 0;
}