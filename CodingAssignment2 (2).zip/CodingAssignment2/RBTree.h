#ifndef RBTREE_H
#define RBTREE_H

#include "RBnode.h"
#include <iostream>
#include <string>
#include <algorithm>

class Tree {

public:
    node* root;

    // constructors
    Tree();
    Tree(int myRoot);

    // other functions
    node* rootGet();

    // helper functions
    void rightRotate(node* z);
    void leftRotate(node* z);
    void transplant(node* u, node* v);
    void insertFixup(node* z);
    node* treeMin(node* root);
    int inOrderTraversal(node* root, std::ostream& out);

    void insert(int z);
    void deleteNode(int z);

    void main();
};

#endif 