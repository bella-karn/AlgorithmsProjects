#include "node.h"

using namespace std;
node::node(int key) : key(key), left(nullptr), right(nullptr), parent(nullptr) {}

node::node(int key, node* left, node* right, node* parent) : key(key), left(left), right(right), parent(parent) {}

// getter functions
int node::getKey() const 
{
    return key;
}

node* node::getLeftChild() const 
{
    return left;
}

node* node::getRightChild() const 
{
    return right;
}

node* node::getParent() const 
{
    return parent;
}
