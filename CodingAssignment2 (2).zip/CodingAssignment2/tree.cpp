#include "tree.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

//constructors
Tree::Tree() : root(nullptr) {}
Tree::Tree(int myRoot) : root(new node(myRoot)) {}

// getter function
node* Tree::rootGet()
{
    return this->root;
}

// insertion function, pretty much just the pseudocode with some bells and whistles
void Tree::insert(int z)
{
    node* y = nullptr;
    node* x = this->rootGet();
    while (x != nullptr) 
    {
        y = x;
        if (z < x->getKey()) 
        {
            x = x->getLeftChild();
        } 
        else 
        {
            x = x->getRightChild();
        }
    }
    node* newNode = new node(z);
    newNode->parent = y;
    if (y == nullptr) 
    {
        this->root = newNode;
    } 
    else if (z < y->getKey()) 
    {
        y->left = newNode;
    } 
    else 
    {
        y->right = newNode;
    }
}

// transplant function, pretty much just the pseduocode with some bells and whistles
void Tree::transplant(node* u, node* v)
{
    if (u->getParent() == nullptr) 
    {
        this->root = v;
    } 
    else if (u->getKey() == u->getParent()->getLeftChild()->getKey()) 
    {
        u->getParent()->left = v;
    } 
    else 
    {
        u->getParent()->right = v;
    }
    if (v != nullptr) {
        v->parent = u->getParent();
    }
}

// ChatGPT helped make this function
node* Tree::treeMin(node* root) {
    if (root == nullptr)
        return nullptr;

    // Traverse the left subtree until the leftmost leaf is reached
    while (root->getLeftChild() != nullptr) {
        root = root->getLeftChild();
    }
    
    // Return the leftmost leaf node
    return root;
}

// also got this function from chatGPT
int Tree::inOrderTraversal(node* root, std::ostream& out) {
    if (root == nullptr)
        return 0;
    else {
        // Traverse the left subtree
        int leftHeight = inOrderTraversal(root->getLeftChild(), out);

        // Visit the current node
        out << root->getKey() << " ";

        // Traverse the right subtree
        int rightHeight = inOrderTraversal(root->getRightChild(), out);

        // Calculate the height of the current node
        int currentHeight = 1 + std::max(leftHeight, rightHeight);

        return currentHeight;
    }
}

// Pretty much just the pseudocode for delete
void Tree::deleteNode(int z)
{
    node* target = rootGet();
    while (target != nullptr && target->getKey() != z) {
        if (z < target->getKey())
            target = target->getLeftChild();
        else
            target = target->getRightChild();
    }

    if (target == nullptr) {
        std::cout << "Node with key " << z << " not found." << std::endl;
        return;
    }

    if (target->getLeftChild() == nullptr) {
        transplant(target, target->getRightChild());
    } else if (target->getRightChild() == nullptr) {
        transplant(target, target->getLeftChild());
    } else {
        node* successor = treeMin(target->getRightChild());
        if (successor->getParent() != target) {
            transplant(successor, successor->getRightChild());
            successor->right = target->getRightChild();
            successor->right->parent = successor;
        }
        transplant(target, successor);
        successor->left = target->getLeftChild();
        successor->left->parent = successor;
    }
    delete target; // Delete the node
}
int main()
{
    // the following is modified from my previous assignments code and also from chatGPT because that was from chatGPT
    std::vector<int> numbers1;
    std::vector<int> numbers2;
    std::vector<int> numbers3;

    // Open the file
    std::ifstream file1("testrandom.csv");
    if (file1.is_open()) {
        std::string line;
        while (std::getline(file1, line)) {
            std::istringstream iss(line);
            int num;
            if (iss >> num) {
                // Assuming there's only one column
                numbers1.push_back(num);
            }
        }
        file1.close();
    } else {
        std::cerr << "Unable to open the file." << std::endl;
        return 1;
    }

    std::ifstream file2("deleteNodes.csv");
    if (file2.is_open()) {
        std::string line;
        while (std::getline(file2, line)) {
            std::istringstream iss(line);
            int num;
            if (iss >> num) {
                // Assuming there's only one column
                numbers2.push_back(num);
            }
        }
        file2.close();
    } else {
        std::cerr << "Unable to open the file." << std::endl;
        return 1;
    }

    std::ifstream file3("testBad.csv");
    if (file3.is_open()) {
        std::string line;
        while (std::getline(file3, line)) {
            std::istringstream iss(line);
            int num;
            if (iss >> num) {
                // Assuming there's only one column
                numbers3.push_back(num);
            }
        }
        file3.close();
    } else {
        std::cerr << "Unable to open the file." << std::endl;
        return 1;
    }

    Tree tree1;
    for (int i = 0; i < numbers1.size(); i++)
    {
        tree1.insert(numbers1[i]);
    }
    std::cout << "In-order traversal:" << std::endl;
    int height1 = tree1.inOrderTraversal(tree1.rootGet(), std::cout);
    std::cout << "\nHeight of the tree: " << height1 << std::endl;
    std::cout << endl;

    Tree tree2;
    for (int i = 0; i < numbers2.size(); i++)
    {
        tree2.insert(numbers2[i]);
    }
    std::cout << "Before delete In-order traversal:" << std::endl;
    int height2 = tree2.inOrderTraversal(tree2.rootGet(), std::cout);
    std::cout << "\nHeight of the tree: " << height2 << std::endl;
    std::cout << endl;

    tree2.deleteNode(7);
    tree2.deleteNode(72);
    std::cout << "After delete In-order traversal:" << std::endl;
    int height3 = tree2.inOrderTraversal(tree2.rootGet(), std::cout);
    std::cout << "\nHeight of the tree: " << height3 << std::endl;
    std::cout << endl;

    Tree tree3;
    for (int i = 0; i < numbers3.size(); i++)
    {
        tree3.insert(numbers3[i]);
    }
    std::cout << "In-order traversal:" << std::endl;
    int height4 = tree3.inOrderTraversal(tree3.rootGet(), std::cout);
    std::cout << "\nHeight of the tree: " << height4 << std::endl;
    std::cout << endl;

    return 0;
}