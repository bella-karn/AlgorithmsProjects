#ifndef TREE_H
#define TREE_H

#include "node.h"
#include <iostream> 

class Tree {

public:
    node* root;

    // constructors
    Tree();
    Tree(int myRoot);

    // other functions
    node* rootGet();
    void transplant(node* u, node* v);
    node* treeMin(node* root);

    //insert and delete stuff
    void insert(int z);
    int inOrderTraversal(node* root, std::ostream& out);
    void deleteNode(int z);

    void main();
};

#endif // TREE_H