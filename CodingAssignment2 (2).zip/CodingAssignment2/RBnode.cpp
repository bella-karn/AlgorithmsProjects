#include "RBnode.h"

using namespace std;
node::node(int key) : key(key), left(nullptr), right(nullptr), parent(nullptr), color("black") {}

node::node(int key, node* left, node* right, node* parent, string rb) : key(key), left(left), right(right), parent(parent), color(rb) {}

int node::getKey() const 
{
    return key;
}

node* node::getLeftChild() const 
{
    return left;
}

node* node::getRightChild() const 
{
    return right;
}

node* node::getParent() const 
{
    return parent;
}

string node::getColor() const
{
    return color;
}
